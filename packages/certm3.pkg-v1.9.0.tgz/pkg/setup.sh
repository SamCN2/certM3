#!/bin/bash

# CertM3 Setup Script
set -e

echo "CertM3 Setup"
echo "============"

# Check dependencies
echo "Checking dependencies..."
MISSING_DEPS=()

if ! command -v node &> /dev/null; then
    MISSING_DEPS+=("Node.js >= 18")
fi

if ! command -v npm &> /dev/null; then
    MISSING_DEPS+=("npm >= 10")
fi

if ! command -v pm2 &> /dev/null; then
    MISSING_DEPS+=("PM2 >= 6")
fi

if ! command -v psql &> /dev/null; then
    MISSING_DEPS+=("PostgreSQL >= 14")
fi

if [ ${#MISSING_DEPS[@]} -ne 0 ]; then
    echo "Missing dependencies:"
    for dep in "${MISSING_DEPS[@]}"; do
        echo "  - $dep"
    done
    echo ""
    echo "Please install missing dependencies before continuing."
    echo "Example installation commands:"
    echo "  # Ubuntu/Debian:"
    echo "  curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -"
    echo "  sudo apt-get install -y nodejs postgresql postgresql-contrib"
    echo "  sudo npm install -g pm2"
    echo ""
    echo "  # CentOS/RHEL:"
    echo "  sudo yum install -y nodejs postgresql postgresql-server"
    echo "  sudo npm install -g pm2"
    exit 1
fi

echo "All dependencies found ✓"

# Create log directories
echo "Creating log directories..."
mkdir -p var/spool/certM3/logs

# Install API dependencies
echo "Installing API dependencies..."
cd api
npm install --omit=dev --legacy-peer-deps
cd ..

echo ""
echo "Setup complete! ✓"
echo ""
echo "Next steps:"
echo "1. Edit config.yaml with your domain and settings"
echo "2. Set up database: sudo -u postgres ./setup-database.sh"
echo "3. Start services: pm2 start etc/certm3.pm2.config.js"
echo "4. Configure nginx (see etc/nginx.certm3-skeleton.conf)"
